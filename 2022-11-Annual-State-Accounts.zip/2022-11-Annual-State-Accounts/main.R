library(stringr)
library(purrr)
library(data.table)

# Goal:
# Organise these into standarised names
# STATE_(optional)type_variable_other(prices)_units_ye/(c2g_(optional)type_variable_other(prices))
asc_c2growth <- function(component, aggregate, period = 4) {
  100 * (
    (component - shift(component, n = period, type = "lag")) /
      shift(aggregate, n = period, type = "lag")
  )
}

state_names_t_a <- c("NSW", "Vic", "Qld", "SA", "WA", "Tas", "ACT", "NT", "Aus")

# Clean names function
asc_clean_names <- function(string, lower = TRUE){
  x <- gsub("[[:punct:][:blank:]]+", " ", string)
  if (lower) {
    tolower(x)
  } else {
    x
  }
}

# add_uplow
add_uplow <- function(string, sentence = FALSE) {
  x <- c(str_to_upper(string),
         str_to_lower(string),
         string)
  if (sentence) {
      x <- c(x, str_to_sentence(string))
    }
  x
}

# Combine states
combine_states <- function(string) {
  paste0(
    paste0("^", str_to_upper(string), collapse = "|"),
    "|",
    str_to_upper(string) |> paste0(collapse = "|"),
    "| ", # intentional spaces
    paste0(str_to_upper(string), collapse = " | "),
    " |", # intentional space
    paste0(paste0("^", str_to_title(string), "[[:punct:]]"), collapse = "|"),
    "|",
    paste0(paste0("^", str_to_title(string), "\\s"), collapse = "|"),
    "| ", # intentional space
    paste0(str_to_lower(string), collapse = " | ")
  )
}

# Paste together
paste3 <- function(...,sep=", ") {
  L <- list(...)
  L <- lapply(L,function(x) {x[is.na(x)] <- ""; x})
  ret <-gsub(paste0("(^",sep,"|",sep,"$)"),"",
             gsub(paste0(sep,sep),sep,
                  do.call(paste,c(L,list(sep=sep)))))
  is.na(ret) <- ret==""
  ret
}

# Combine patterns
combine_patterns <- function(string, space = FALSE, edges = FALSE) {
  if (space) {
      x <- c(paste0(string, collapse = " | "),
             paste0(string, collapse = "|")) |>
        paste0(collapse = "|")
    } else {
      x <- paste0(string, collapse = "|")
    }
  if (edges) {
   x <-  paste0(
           paste0(
             paste0("^", string, collapse = "|"),
             "|",
             paste0(string, "$", collapse = "|")
             ), "|", x
    )
  }
  x
}

# Extract state
extract_state <- function(string, raw = FALSE) {
  p <- combine_states(state_names_t_a)

  if (raw) {map_chr(string, ~ str_trim(str_extract(.x, p)))
  } else {
    map_chr(string, ~ str_trim(str_extract(.x, p))) |>
      asc_clean_names() |>
      str_trim() |>
      str_to_upper()
  }
}

## Extract prices
extract_prices <- function(string, raw = FALSE) {
  p <-
    combine_patterns(c(add_uplow(
      c(
        paste0(add_uplow("chain volumes[[:punct:]]?\\s+"), "[[:digit:]]+\\s+[[:digit:]]+ prices"),
        paste0(add_uplow("chain volumes[[:punct:]]?\\s+"), "[[:digit:]]+\\s*/\\s*[[:digit:]]+ prices"),
        "chain volumes",
        "current prices"
      )
    )),
    space = FALSE,
    edges = TRUE)

  if (raw) {map_chr(string, ~ str_trim(str_extract(.x, p)))
  } else {
    tolower(map_chr(string, ~ str_trim(str_extract(.x, p)))) |>
      asc_clean_names() |>
      str_trim()
  }
}

## Extract units
extract_units <- function(string, raw = FALSE) {
  p <-
    combine_patterns(add_uplow(
      c(
        "\\$m",
        "\\$b",
        "000s",
        "millions",
        "billions",
        "thousands",
        "\\$000s",
        "\\$\'000"
      ),
      sentence = TRUE
    ),
    space = TRUE,
    edges = TRUE)

  x <- map_chr(string, ~ str_trim(str_extract(.x, p)))

  if (raw) {
    map_chr(x, ~ {
      if (isTRUE(str_detect(str_sub(.x, 1, 1), "[[:symbol:]]"))) {
        paste0("\\", .x)
      } else {
        .x
      }
    })
  } else {
    x |>
      asc_clean_names() |>
      str_trim()
  }
}


## Extract transformation
extract_transf <- function(string, raw = FALSE) {
  p <- combine_patterns(add_uplow(c("_ye", "_c2g")),
                        space = TRUE,
                        edges = TRUE)

  if (raw) {map_chr(string, ~ str_trim(str_extract(.x, p)))
  } else {
    tolower(map_chr(string, ~ str_trim(str_extract(.x, p)))) |>
      asc_clean_names() |>
      str_trim()
  }
}

## Extract Variable
extract_variable <- function(string, raw = FALSE) {
  x <- map_chr(string,  ~ {
    present <- na.omit(
      c(extract_state(.x, TRUE),
        extract_prices(.x, TRUE),
        extract_units(.x, TRUE),
        extract_transf(.x, TRUE))
      )

    fromtoSTR(x = .x,
              from = present,
              to = rep("", length(present)))
    }
  ) |> str_trim()

  # Remove fragments of states


  if (raw) {
    x
  } else {
    tolower(x) |>
      asc_clean_names() |>
      str_trim()
  }
}

