asc_c2growth <- function(component, aggregate, period = 4) {
  100 * (
    (component - shift(component, n = period, type = "lag")) /
      shift(aggregate, n = period, type = "lag")
  )
}

#' Coerce to date or return false (for use inside datarequestutil package)
#'
#' Given a string as input, datefalse will return a date in YYYY-MM-DD format,
#' or false if the string cannot be coerced to a date.
#'
#' @param string A string to test for coercion to as.Date format.
#' @param check If TRUE (the default), returns TRUE if string can be coerced to a
#'     date. If set to FALSE, returns the string itself, coerced to a date.
#'
#' @return a base::as.Date() object, or FALSE

#'
#' @examples
#' datefalse("2022-10-24") # returns a date
#' datefalse("fdfjdk") # returns FALSE
datefalse_internal <- function(string, check = TRUE) {
  patterns <-
    c(
      '[0-9][0-9][0-9][0-9]/[0-9][0-9]/[0-9][0-9]',
      '[0-9][0-9]/[0-9][0-9]/[0-9][0-9][0-9][0-9]',
      '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'
    )
  formatdates <- c('%Y/%m/%d', '%d/%m/%Y', '%Y-%m-%d')
  standardformat <- '%Y-%m-%d'
  for (i in 1:3) {
    if (grepl(patterns[i], string)) {
      aux <- base::as.Date(string, format = formatdates[i])
      if (!is.na(aux)) {
        if (check) {
          return(TRUE)
        } else {
          return(base::as.Date(format(aux, standardformat)))
        }
      }
    }
  }
  return(FALSE)
}







#' Create sequences of dates
#'
#' This is a convenience wrapper for base::seq.Date. This is useful in data
#' requests where you just receive the data values, and need to create a date
#' column yourself.
#'
#' @param from A date, or string coercible to a date.
#' @param by One of "Y", "Q", "M", "D", "W", "H".
#' \itemize{
#'   \item "D" for daily intervals
#'   \item "W" for weekly intervals
#'   \item "M" for monthly intervals
#'   \item "Q" for quarterly intervals
#'   \item "H" for half-yearly intervals
#'   \item "Y" for yearly intervals
#'   }
#' @param to A positive integer, date, or string coercible to a date.
#'
#' @return A character vector of dates.
#' @export
#'
#' @examples
#' dateseq("2022-01-01", "M", 3) # first day of Jan, Feb, and Mar 2022
dateseq <- function(from, by, to) {

  # GR 1 - check that three arguments were provided
  if (nargs() < 3) {
    stop("Please provide all three arguments.")
  }

  # GR 2 - if from is not coercible to a date, error
  if (!datefalse_internal(from)) {
    stop("from must be coercible to a date, ideally YYYY-MM-DD format.")
  } else {
    from <- datefalse_internal(from, FALSE)
  }

  # GR 3 - check that by is correctly specified
  if (!(by %in% c("Y", "Q", "M", "D", "W", "H"))) {
    stop("by must be one of Y, H, Q, M, W, D")
  } else {
    by <- switch(
      by,
      Y = {
        "year"
      },
      Q = {
        "quarter"
      },
      M = {
        "month"
      },
      D = {
        "day"
      },
      W = {
        "week"
      },
      H = {
        "6 month"
      }
    )
  }

  # GR 4 - check that to is correctly specified
  if (!datefalse_internal(to)) {
    if (!is.numeric(to)) {
      stop("to must be a date or positive integer.")
    } else {
      to <- as.integer(to)
      if (by <= 0) {
        stop("by must be a positive integer.")
      }
    }
  } else {
    to <- datefalse_internal(to, FALSE)
  }

  if (is.integer(to)) {
    seq.Date(from = from,
             by = by,
             length.out = to)
  } else {
    seq.Date(from = from, to = to, by = by)
  }

}

fromtoSTR <- function(x, from, to, warn_missing = TRUE) {
  if (length(from) != length(to)) {
    stop("`from` and `to` vectors are not the same length.")
  }

  if (!is.character(x)) {
    stop("x must be a character vector.")
  }

  overall_test <- grepl(paste0(from, collapse = "|"), x)

  for (i in seq_along(x)) {
    if (overall_test[i]) {
      for (j in seq_along(from)) {
        x[i] <- gsub(from[j], to[j], x[i])
      }

    }
  }
  x
}

merge_select <- function(on, vars, ..., suffix = "_") {
  dts <- list(...)
  names(dts) <- sapply(as.list(substitute(list(...)))[-1L], deparse)

  nv <- length(vars)
  ndt <- length(dts)

  old_cols <- split(rep(vars, ndt),
                    ceiling(seq_along(rep(vars, ndt))/nv))

  new_cols <- split(paste0(vars, suffix, rep(names(dts), each = nv)),
                    ceiling(seq_along(paste0(vars,
                                             suffix,
                                             rep(names(dts), each = nv)))/nv))

  sep_cols <- lapply(dts, function(x) subset(x, select = c(on, vars)))

  Reduce(f = function(x,y) merge(x, y, by = on),
         Map(f = setnames, sep_cols, old_cols, new_cols))
}

# Read all sheets of an xlsx
read_all_sheets.xlsx = function(xlsxFile, ...) {
  sheet_names = openxlsx::getSheetNames(xlsxFile)
  sheet_list = as.list(rep(NA, length(sheet_names)))
  names(sheet_list) = sheet_names
  for (sn in sheet_names) {
    sheet_list[[sn]] = openxlsx::read.xlsx(xlsxFile, sheet = sn, ...)
  }
  return(sheet_list)
}
